Tao_bao_hunter
==============

A simple tao bao auto buyer based on chrome extension

Description
==============

This is a chrome extension, for user to auto buy thing on www.taobao.com site, for more details, pls visit my blog http://blog.csdn.net/ivan_zjj
