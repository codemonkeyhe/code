$(document).ready( function(){
	document.getElementById("TPL_username_1").value = username ;
	document.getElementById("TPL_password_1").value = pwd ; 
	document.getElementById("J_StaticForm").submit() ;
});