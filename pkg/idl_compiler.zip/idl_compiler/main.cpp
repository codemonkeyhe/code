#include "service_info.h"

extern int yyparse();

int main(int argc, char* argv[])
{
    yyparse();

    g_request_info.show();
    g_response_info.show();

    return 0;
}
