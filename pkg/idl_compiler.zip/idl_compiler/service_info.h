#ifndef SERVICE_INFO_H
#define SERVICE_INFO_H

#include <inttypes.h>
#include <map>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <sstream>

enum LimitType
{
    LIMIT_NONE,
    LIMIT_INT,
    LIMIT_DOUBLE
};

struct FieldInfo
{
    bool optional;
    std::string name;
    std::string type_name;

    enum LimitType limit_type;
    union
    {
        struct
        {
            int64_t max;
            int64_t min;
        } int_limit;

        struct
        {
            double max;
            double min;
        } dou_limit;
    } limit;

    FieldInfo()
    {
        reset();
    }

    void reset()
    {
        limit_type = LIMIT_NONE;
    }
};

class FieldInfoTable
{
public:
    typedef std::map<std::string, struct FieldInfo> FieldInfoMap;

public:
    FieldInfoTable(bool is_request);

    void reset();
    void show();
    void swap(FieldInfoTable& another);

    const FieldInfoMap& get_field_info_map() const;
    void add_field_info(const struct FieldInfo& field_info);

private:
    bool _is_request;
    FieldInfoMap _field_info_map;
};

extern FieldInfoTable g_request_info;
extern FieldInfoTable g_response_info;

template <typename T>
std::string any2string(T t)
{
    std::stringstream ss;
    ss << t;
    return ss.str();
}

extern int yylineno;
extern char* yytext;
extern int yylex(void);
extern void yyerror(const char* format, ...);

#endif // SERVICE_INFO_H
