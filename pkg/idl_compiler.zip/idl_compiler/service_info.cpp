#include "service_info.h"

FieldInfoTable g_request_info(true);
FieldInfoTable g_response_info(false);

FieldInfoTable::FieldInfoTable(bool is_request)
    : _is_request(is_request)
{
}

void FieldInfoTable::reset()
{
    _field_info_map.clear();
}

void FieldInfoTable::show()
{
    if (_field_info_map.empty())
    {
        printf("empty\n");
    }
    else
    {
        std::string type = _is_request? "request": "response";
        printf("%s ==> \n", type.c_str());

        for (FieldInfoMap::iterator iter=_field_info_map.begin();
                iter!=_field_info_map.end(); ++iter)
        {
            const struct FieldInfo& field_info = iter->second;
            std::string tag = field_info.optional? "optional": "required";

            std::string min, max;
            if (LIMIT_INT == field_info.limit_type)
            {
                min = any2string(field_info.limit.int_limit.min);
                max = any2string(field_info.limit.int_limit.max);
            }
            else if (LIMIT_DOUBLE == field_info.limit_type)
            {
                min = any2string(field_info.limit.dou_limit.min);
                max = any2string(field_info.limit.dou_limit.max);
            }

            printf("\t<%s> %s %s (%s, %s)\n",
                    tag.c_str(),
                    field_info.type_name.c_str(), field_info.name.c_str(),
                    min.c_str(), max.c_str());
        }
    }
}

void FieldInfoTable::swap(FieldInfoTable& another)
{
    const FieldInfoMap& field_info_map = another.get_field_info_map();

    for (FieldInfoMap::const_iterator iter=field_info_map.begin();
            iter!=field_info_map.end(); ++iter)
    {
        const struct FieldInfo& field_info = iter->second;
        add_field_info(field_info);
    }

    another.reset();
}

const FieldInfoTable::FieldInfoMap& FieldInfoTable::get_field_info_map() const
{
    return _field_info_map;
}

void FieldInfoTable::add_field_info(const struct FieldInfo& field_info)
{
    std::pair<FieldInfoMap::iterator, bool> ret =
            _field_info_map.insert(std::make_pair(field_info.name, field_info));

    if (!ret.second)
    {
        yyerror("Syntax error: repeat field: in request\n", field_info.name.c_str());
        exit(1);
    }
}

void yyerror(const char* format, ...)
{
    fprintf(stderr, "[ERROR:%d] (last token was '%s')\n", yylineno, yytext);

    va_list args;
    va_start(args, format);
    vfprintf(stderr, format, args);
    va_end(args);
}
