read -p "f1: "  first
read -p "f2: "  second
echo -e "\n Input is $first $second"
