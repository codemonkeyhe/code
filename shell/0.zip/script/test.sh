#!/bin/bash
hh=god
echo $hh >> /data/home/monkeyhe/work/script/data.run.log 2>&1
